# urun_tanimak > 2024-05-21 9:59am
https://universe.roboflow.com/computervision-of3yl/urun_tanimak

Provided by a Roboflow user
License: CC BY 4.0

